#!/usr/bin/env python3
"""
doc_rollup (continuity-kit) — mantem os docs de historico/evolucao de um projeto
apos uma sessao significativa, SEM decair como os originais decairam.

Generaliza o padrao real de manter documentos de historico (changelog + timeline
narrativa + snapshot de estado + licoes + wrapup por sessao) espalhado por um
`rollup.yaml` config-driven, em vez de hardcoded a um projeto especifico.

Licao embutida desde o dia 1 (nao descoberta depois): documentos de narrativa manual
crescem sem limite e viram lixo que ninguem le. Acima de `max_bytes` (default 65536)
OU `max_entries` entradas gerenciadas, o rollup para de escrever a narrativa completa
e passa a escrever so 1 linha-carimbo + ponteiro pro estado vivo (`pointer` do target).

Modos de escrita (NUNCA sobrescrevem o arquivo inteiro):
  prepend-after-header  -> insere logo apos a 1a linha em branco do arquivo
  append-section        -> anexa no final do arquivo
  create-new            -> cria arquivo novo (path pode usar {date}); se ja existir
                            no path resolvido, e NO-OP (nunca sobrescreve)
  header-and-section     -> substitui SÓ o conteudo entre marcadores
                            <!-- ROLLUP:SNAPSHOT:BEGIN/END --> (cria os marcadores se
                            preciso); o resto do arquivo fica intocado.

Guardrails (codigo, nao so doutrina):
  - backup `<path>.bak-rollup-<timestamp>` ANTES de editar arquivo existente
  - escrita atomica (tmp + os.replace)
  - colisao: mesmo `session_marker` ja presente no alvo -> aborta ESSE alvo (nao o run
    inteiro), LC-4 (idempotencia — nao re-inserir o que ja foi inserido)
  - `passive: true` no target -> RECUSA escrever, sempre, mesmo que o config peça
    (defesa em profundidade p/ paths tipo mirror auto-gerado)

Uso:
    echo '{...}' | python doc_rollup.py plan  --stdin --config rollup.yaml
    echo '{...}' | python doc_rollup.py apply --stdin --config rollup.yaml [--dry-run] [--force]
    python doc_rollup.py --self-test

Exit: 0 ok (mesmo com targets pulados/degradados — isso e comportamento correto,
não falha) · 1 payload invalido (falta session_marker/resumo/re_derive_cmd de uma
métrica) · 2 uso invalido (JSON malformado, config ausente).
stdlib + PyYAML.
v1.0.0 — 2026-07-10 (continuity-kit · Tier 2 · doc-rollup generico)
"""
from __future__ import annotations

import argparse
import json
import os
import re
import shutil
import sys
from datetime import datetime, timedelta, timezone
from pathlib import Path

try:
    import yaml  # PyYAML
except ImportError:
    yaml = None  # type: ignore[assignment]

_MAX_BYTES_DEFAULT = 65536  # mesma constante de hooks/_handoff_io.py deste kit
_MAX_ENTRIES_DEFAULT = 30
_SNAPSHOT_BEGIN = "<!-- ROLLUP:SNAPSHOT:BEGIN -->"
_SNAPSHOT_END = "<!-- ROLLUP:SNAPSHOT:END -->"
_VALID_MODES = ("prepend-after-header", "append-section", "create-new", "header-and-section")


def _brt_today() -> str:
    return datetime.now(timezone(timedelta(hours=-3))).strftime("%Y-%m-%d")


def load_config(path: Path) -> dict:
    if yaml is None or not path.exists():
        return {}
    try:
        return yaml.safe_load(path.read_text(encoding="utf-8")) or {}
    except Exception:  # noqa: BLE001
        return {}


def validate_payload(payload: dict) -> list:
    """Retorna lista de erros (vazia = valido). Guardrails LC-1/LC-4 aplicados aqui."""
    errors = []
    if not isinstance(payload, dict):
        return ["payload nao e um objeto JSON"]
    if not str(payload.get("session_marker") or "").strip():
        errors.append("session_marker ausente (obrigatorio p/ deteccao de colisao/idempotencia — LC-4)")
    if not str(payload.get("resumo") or "").strip():
        errors.append("resumo ausente")
    for i, m in enumerate(payload.get("metricas") or []):
        if not isinstance(m, dict) or not str(m.get("re_derive_cmd") or "").strip():
            errors.append(f"metricas[{i}] sem re_derive_cmd (LC-1: todo numero precisa de comando pra re-derivar ao vivo)")
    return errors


def _bullets(items: list) -> str:
    items = [str(i) for i in (items or []) if str(i).strip()]
    return "\n".join(f"- {i}" for i in items) if items else "- (nenhum registrado)"


def _metricas_table(metricas: list) -> str:
    rows = [m for m in (metricas or []) if isinstance(m, dict)]
    if not rows:
        return "_(sem metricas nesta sessao)_"
    lines = ["| Metrica | Antes | Depois | Re-derivar |", "|---|---|---|---|"]
    for m in rows:
        lines.append(f"| {m.get('nome', '?')} | {m.get('antes', '?')} | {m.get('depois', '?')} | `{m.get('re_derive_cmd', '')}` |")
    return "\n".join(lines)


def render_template(template: str, payload: dict) -> str:
    fields = {
        "date": payload.get("date") or _brt_today(),
        "resumo": payload.get("resumo", ""),
        "shipments_bullets": _bullets(payload.get("shipments")),
        "metricas_table": _metricas_table(payload.get("metricas")),
        "decisoes_bullets": _bullets(payload.get("decisoes")),
        "aprendizados_bullets": _bullets(payload.get("aprendizados")),
    }
    try:
        return template.format(**fields)
    except (KeyError, IndexError):
        # template referencia campo desconhecido — nao quebra o run, so nao substitui
        out = template
        for k, v in fields.items():
            out = out.replace("{" + k + "}", str(v))
        return out


def render_stamp(payload: dict, pointer: str) -> str:
    date = payload.get("date") or _brt_today()
    resumo = str(payload.get("resumo", ""))[:160]
    return f"> **Carimbo {date}:** {resumo} — {pointer or 'ver o estado vivo do projeto'}.\n"


def _count_entries(text: str, marker: str | None) -> int:
    if not marker or not text:
        return 0
    try:
        return len(re.findall(marker, text, re.M))
    except re.error:
        return 0


def should_degrade(existing_text: str, target: dict) -> bool:
    max_bytes = int(target.get("max_bytes", _MAX_BYTES_DEFAULT))
    max_entries = target.get("max_entries")
    if len(existing_text.encode("utf-8")) > max_bytes:
        return True
    if max_entries is not None and _count_entries(existing_text, target.get("entry_marker")) >= int(max_entries):
        return True
    return False


def _has_collision(existing_text: str, session_marker: str) -> bool:
    return bool(session_marker) and session_marker in existing_text


def _read(path: Path) -> str:
    try:
        return path.read_text(encoding="utf-8")
    except OSError:
        return ""


def _insert_prepend_after_header(existing: str, new_entry: str, session_marker: str) -> str:
    """Insere a entrada mais nova no TOPO da pilha de entradas gerenciadas. Marca a
    entrada com o session_marker num comentario HTML invisivel (p/ deteccao de colisao
    E p/ achar o inicio da pilha em chamadas futuras — nao usar 'a 1a linha em branco'
    como fronteira: uma entrada com blank line NO PROPRIO CORPO (comum — titulo em
    branco antes do corpo) faria a proxima entrada ser inserida DENTRO da anterior)."""
    marker_line = f"<!-- rollup:{session_marker} -->\n"
    block = marker_line + new_entry.rstrip("\n") + "\n\n"
    if not existing:
        return block
    idx = existing.find("<!-- rollup:")
    if idx != -1:
        # ja existe >=1 entrada gerenciada -- empilha a nova IMEDIATAMENTE antes da
        # primeira, preservando qualquer cabecalho humano acima delas.
        return existing[:idx] + block + existing[idx:]
    # 1a entrada gerenciada deste arquivo -- pode haver cabecalho humano (titulo/intro)
    # acima; insere apos a 1a linha em branco, ou no topo se nao houver nenhuma.
    lines = existing.splitlines(keepends=True)
    for i, ln in enumerate(lines):
        if ln.strip() == "":
            return "".join(lines[: i + 1]) + block + "".join(lines[i + 1:])
    return existing.rstrip("\n") + "\n\n" + block


def _insert_append_section(existing: str, new_entry: str, session_marker: str) -> str:
    marker_line = f"<!-- rollup:{session_marker} -->\n"
    block = marker_line + new_entry.rstrip("\n") + "\n"
    if not existing:
        return block
    return existing.rstrip("\n") + "\n\n" + block


def _insert_header_and_section(existing: str, new_entry: str, session_marker: str) -> str:
    marker_line = f"<!-- rollup:{session_marker} -->\n"
    section = _SNAPSHOT_BEGIN + "\n" + marker_line + new_entry.strip("\n") + "\n" + _SNAPSHOT_END
    if _SNAPSHOT_BEGIN in existing and _SNAPSHOT_END in existing:
        pre, _, rest = existing.partition(_SNAPSHOT_BEGIN)
        _, _, post = rest.partition(_SNAPSHOT_END)
        return pre + section + post
    if not existing:
        return section + "\n"
    return existing.rstrip("\n") + "\n\n" + section + "\n"


def plan_target(target: dict, payload: dict, repo_root: Path) -> dict:
    """Calcula a acao p/ um alvo, SEM tocar disco. Retorna relatorio por alvo."""
    rel_path = str(target.get("path", ""))
    mode = str(target.get("mode", ""))
    result = {"path": rel_path, "mode": mode, "role": target.get("role", "")}

    if target.get("passive"):
        result["status"] = "skipped-passive"
        result["reason"] = "path marcado passive: true — doc_rollup.py nunca escreve aqui"
        return result

    if mode not in _VALID_MODES:
        result["status"] = "error"
        result["reason"] = f"mode invalido: {mode!r} (validos: {', '.join(_VALID_MODES)})"
        return result

    resolved_rel = rel_path.format(date=payload.get("date") or _brt_today())
    full_path = repo_root / resolved_rel
    result["resolved_path"] = str(full_path)

    if mode == "create-new":
        if full_path.exists():
            result["status"] = "skipped-exists"
            result["reason"] = "create-new: path resolvido ja existe — nunca sobrescreve"
            return result
        result["status"] = "would-create"
        result["content_preview"] = render_template(target.get("template", ""), payload)
        return result

    existing = _read(full_path)
    session_marker = str(payload.get("session_marker", ""))

    region = existing
    if mode == "header-and-section" and _SNAPSHOT_BEGIN in existing:
        region = existing.split(_SNAPSHOT_BEGIN, 1)[1].split(_SNAPSHOT_END, 1)[0]

    if _has_collision(region, session_marker):
        result["status"] = "skipped-collision"
        result["reason"] = f"session_marker {session_marker!r} ja presente neste alvo (LC-4: nao re-inserir)"
        return result

    if mode != "header-and-section" and should_degrade(existing, target):
        result["status"] = "would-stamp-degrade"
        result["reason"] = "alvo passou do limiar (max_bytes/max_entries) — escrevendo so carimbo"
        result["content_preview"] = render_stamp(payload, target.get("pointer", ""))
        return result

    result["status"] = f"would-{'prepend' if mode == 'prepend-after-header' else 'append' if mode == 'append-section' else 'update-section'}"
    result["content_preview"] = render_template(target.get("template", ""), payload)
    return result


def apply_target(target: dict, payload: dict, repo_root: Path, dry_run: bool) -> dict:
    plan = plan_target(target, payload, repo_root)
    status = plan["status"]
    if status in ("skipped-passive", "skipped-exists", "skipped-collision", "error"):
        return plan
    if dry_run:
        plan["status"] = f"dry-run:{status}"
        return plan

    mode = plan["mode"]
    session_marker = str(payload.get("session_marker", ""))
    full_path = Path(plan["resolved_path"])

    if status == "would-create":
        full_path.parent.mkdir(parents=True, exist_ok=True)
        tmp = full_path.with_suffix(full_path.suffix + ".tmp")
        tmp.write_text(plan["content_preview"], encoding="utf-8")
        os.replace(tmp, full_path)
        plan["status"] = "created"
        return plan

    existing = _read(full_path)
    if existing:
        backup = full_path.with_name(full_path.name + f".bak-rollup-{_stamp_now()}")
        try:
            shutil.copy2(full_path, backup)
            plan["backup"] = str(backup)
        except OSError:
            pass

    if status == "would-stamp-degrade":
        new_text_body = render_stamp(payload, target.get("pointer", ""))
    else:
        new_text_body = render_template(target.get("template", ""), payload)

    if mode == "prepend-after-header":
        new_text = _insert_prepend_after_header(existing, new_text_body, session_marker)
    elif mode == "append-section":
        new_text = _insert_append_section(existing, new_text_body, session_marker)
    else:  # header-and-section
        new_text = _insert_header_and_section(existing, new_text_body, session_marker)

    full_path.parent.mkdir(parents=True, exist_ok=True)
    tmp = full_path.with_suffix(full_path.suffix + ".tmp")
    tmp.write_text(new_text, encoding="utf-8")
    os.replace(tmp, full_path)
    plan["status"] = "applied:" + status.replace("would-", "")
    return plan


def _stamp_now() -> str:
    return datetime.now().strftime("%Y%m%d-%H%M%S%f")


def run(config: dict, payload: dict, dry_run: bool) -> dict:
    report = {"repos": []}
    for repo in config.get("repos") or []:
        root = Path(repo.get("root", "."))
        if not root.is_absolute():
            root = Path.cwd() / root
        repo_report = {"name": repo.get("name", "?"), "root": str(root), "targets": []}
        for target in repo.get("targets") or []:
            repo_report["targets"].append(apply_target(target, payload, root, dry_run))
        report["repos"].append(repo_report)
    return report


def _plan_only(config: dict, payload: dict) -> dict:
    report = {"repos": []}
    for repo in config.get("repos") or []:
        root = Path(repo.get("root", "."))
        if not root.is_absolute():
            root = Path.cwd() / root
        repo_report = {"name": repo.get("name", "?"), "root": str(root), "targets": []}
        for target in repo.get("targets") or []:
            repo_report["targets"].append(plan_target(target, payload, root))
        report["repos"].append(repo_report)
    return report


def _self_test() -> int:
    import tempfile

    tmp = Path(tempfile.mkdtemp(prefix="doc_rollup_selftest_"))
    try:
        payload = {
            "session_marker": "sess-selftest-001",
            "date": "2026-07-10",
            "resumo": "self-test do doc_rollup",
            "shipments": ["item A", "item B"],
            "metricas": [{"nome": "arquivos", "antes": "1", "depois": "2", "re_derive_cmd": "ls | wc -l"}],
            "decisoes": ["usar X em vez de Y"],
            "aprendizados": ["sempre validar antes de aplicar"],
        }

        # 1) validate_payload: payload valido -> sem erros
        assert validate_payload(payload) == []
        # 1b) payload sem session_marker/resumo/re_derive_cmd -> rejeitado
        bad = {"metricas": [{"nome": "x"}]}
        errs = validate_payload(bad)
        assert any("session_marker" in e for e in errs)
        assert any("resumo" in e for e in errs)
        assert any("re_derive_cmd" in e for e in errs)

        # 2) prepend-after-header cria arquivo novo corretamente
        cfg = {
            "repos": [{
                "name": "t", "root": str(tmp),
                "targets": [
                    {"path": "CHANGELOG.md", "role": "changelog", "mode": "prepend-after-header",
                     "entry_marker": r"^## \[", "max_bytes": 65536, "max_entries": 30,
                     "pointer": "ver git log", "template": "## [{date}] {resumo}\n\n{shipments_bullets}\n"},
                ],
            }],
        }
        rep1 = run(cfg, payload, dry_run=False)
        t1 = rep1["repos"][0]["targets"][0]
        assert t1["status"] == "applied:prepend", t1
        changelog_path = tmp / "CHANGELOG.md"
        text1 = changelog_path.read_text(encoding="utf-8")
        assert "self-test do doc_rollup" in text1
        assert "sess-selftest-001" in text1

        # 3) re-aplicar o MESMO session_marker -> colisao, NAO duplica
        rep2 = run(cfg, payload, dry_run=False)
        t2 = rep2["repos"][0]["targets"][0]
        assert t2["status"] == "skipped-collision", t2
        text2 = changelog_path.read_text(encoding="utf-8")
        assert text2.count("sess-selftest-001") == 1, "colisao deveria ter impedido duplicata"

        # 4) segunda sessao (marker diferente) -> aplica de novo, sem apagar a primeira
        payload3 = dict(payload, session_marker="sess-selftest-002", resumo="segunda sessao")
        rep3 = run(cfg, payload3, dry_run=False)
        assert rep3["repos"][0]["targets"][0]["status"] == "applied:prepend"
        text3 = changelog_path.read_text(encoding="utf-8")
        assert "sess-selftest-001" in text3 and "sess-selftest-002" in text3
        # prepend: a entrada mais recente fica ANTES da mais antiga
        assert text3.index("sess-selftest-002") < text3.index("sess-selftest-001")

        # 5) degradacao: max_entries=1 já atingido -> 3a sessao vira carimbo, nao narrativa completa
        cfg_deg = json.loads(json.dumps(cfg))
        cfg_deg["repos"][0]["targets"][0]["max_entries"] = 1
        payload4 = dict(payload, session_marker="sess-selftest-003", resumo="terceira sessao (deve degradar)")
        rep4 = run(cfg_deg, payload4, dry_run=False)
        t4 = rep4["repos"][0]["targets"][0]
        assert t4["status"] == "applied:stamp-degrade", t4
        text4 = changelog_path.read_text(encoding="utf-8")
        assert "Carimbo 2026-07-10" in text4
        assert "terceira sessao (deve degradar)" in text4

        # 6) path passive: true -> NUNCA escreve, mesmo que o config peça
        cfg_passive = {
            "repos": [{"name": "t", "root": str(tmp), "targets": [
                {"path": "mirror/should-not-exist.md", "role": "mirror-passive", "passive": True, "mode": "append-section"},
            ]}],
        }
        rep5 = run(cfg_passive, payload, dry_run=False)
        t5 = rep5["repos"][0]["targets"][0]
        assert t5["status"] == "skipped-passive", t5
        assert not (tmp / "mirror" / "should-not-exist.md").exists()

        # 7) create-new: 2a chamada no MESMO {date} -> no-op (nunca sobrescreve)
        cfg_new = {
            "repos": [{"name": "t", "root": str(tmp), "targets": [
                {"path": "sessions/{date}-WRAPUP.md", "role": "session-wrapup", "mode": "create-new",
                 "template": "# Wrapup {date}\n\n{resumo}\n"},
            ]}],
        }
        rep6a = run(cfg_new, payload, dry_run=False)
        assert rep6a["repos"][0]["targets"][0]["status"] == "created"
        wrapup_path = tmp / "sessions" / "2026-07-10-WRAPUP.md"
        original_bytes = wrapup_path.read_bytes()
        rep6b = run(cfg_new, dict(payload, resumo="tentativa de sobrescrever"), dry_run=False)
        assert rep6b["repos"][0]["targets"][0]["status"] == "skipped-exists"
        assert wrapup_path.read_bytes() == original_bytes, "create-new nao deveria sobrescrever"

        # 8) header-and-section: substitui só a secao, preserva conteudo fora dela
        section_path = tmp / "STATE.md"
        section_path.write_text("# Estado\n\nconteudo preservado antes\n", encoding="utf-8")
        cfg_snap = {
            "repos": [{"name": "t", "root": str(tmp), "targets": [
                {"path": "STATE.md", "role": "snapshot", "mode": "header-and-section",
                 "pointer": "ver SSoT", "template": "{resumo}\n"},
            ]}],
        }
        run(cfg_snap, payload, dry_run=False)
        text8a = section_path.read_text(encoding="utf-8")
        assert "conteudo preservado antes" in text8a
        assert _SNAPSHOT_BEGIN in text8a and _SNAPSHOT_END in text8a
        run(cfg_snap, dict(payload, session_marker="sess-selftest-999", resumo="estado atualizado"), dry_run=False)
        text8b = section_path.read_text(encoding="utf-8")
        assert "conteudo preservado antes" in text8b, "conteudo fora da secao deveria sobreviver"
        assert "estado atualizado" in text8b
        assert "self-test do doc_rollup" not in text8b, "header-and-section deveria SUBSTITUIR a secao anterior"

        # 9) dry-run nunca toca disco
        fresh_path = tmp / "DRYRUN.md"
        cfg_dry = {"repos": [{"name": "t", "root": str(tmp), "targets": [
            {"path": "DRYRUN.md", "role": "changelog", "mode": "append-section", "template": "{resumo}\n"},
        ]}]}
        run(cfg_dry, payload, dry_run=True)
        assert not fresh_path.exists(), "dry-run nao deveria criar arquivo"

        # 10) plan_target isolado nao toca disco (usado pelo subcomando `plan`)
        _plan_only(cfg_dry, payload)
        assert not fresh_path.exists()

        print("self-test OK — insercao/colisao/degradacao/passive/create-new/header-section/dry-run")
        return 0
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(prog="doc_rollup.py")
    sub = p.add_subparsers(dest="cmd")
    for name in ("plan", "apply"):
        sp = sub.add_parser(name)
        sp.add_argument("--stdin", action="store_true")
        sp.add_argument("--config", default="rollup.yaml")
        if name == "apply":
            sp.add_argument("--dry-run", action="store_true")
            sp.add_argument("--force", action="store_true")
    p.add_argument("--self-test", action="store_true")
    return p


def main(argv) -> int:
    args = build_parser().parse_args(argv)

    if args.self_test:
        return _self_test()

    if args.cmd not in ("plan", "apply"):
        print("uso: doc_rollup.py {plan|apply} --stdin --config rollup.yaml [--dry-run]", file=sys.stderr)
        return 2

    if yaml is None:
        print("doc_rollup: PyYAML ausente", file=sys.stderr)
        return 2

    if not args.stdin:
        print("uso: --stdin e obrigatorio (o payload vem do modelo, nao de arquivo)", file=sys.stderr)
        return 2

    try:
        raw = sys.stdin.read()
        payload = json.loads(raw) if raw.strip() else {}
    except json.JSONDecodeError as e:
        print(f"doc_rollup: JSON invalido no stdin: {e}", file=sys.stderr)
        return 2

    errors = validate_payload(payload)
    if errors and not (args.cmd == "apply" and getattr(args, "force", False)):
        print(json.dumps({"status": "rejected", "errors": errors}, ensure_ascii=False, indent=2))
        return 1

    config_path = Path(args.config)
    config = load_config(config_path)
    if not config:
        print(f"doc_rollup: config ausente/vazia: {config_path} (copie rollup.example.yaml)", file=sys.stderr)
        return 2

    if args.cmd == "plan":
        report = _plan_only(config, payload)
    else:
        report = run(config, payload, dry_run=getattr(args, "dry_run", False))

    print(json.dumps(report, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    try:
        sys.stdout.reconfigure(encoding="utf-8")  # type: ignore[attr-defined]
    except (AttributeError, ValueError):
        pass
    sys.exit(main(sys.argv[1:]))
