#!/usr/bin/env bash
# handoff-roundtrip-C1-C4.sh — os 4 casos de aceite do continuity-kit, via a interface REAL
# de hook (stdin JSON -> stdout JSON), contra _handoff_io.py / handoff_inject.py /
# handoff_guard.py de verdade. Roda 3x e exige resultado idêntico (pass^k=1.00, k=3 —
# loop-passk REGRA 2).
#
# C1 · round-trip básico: write --demo -> handoff_inject imprime bloco LC-4 -> ledger tem "consumed"
# C2 · staleness: valid_until expirado -> inject mostra STALE e NÃO mostra PRÓXIMO PASSO
# C3 · degraded-auto: sem handoff, Stop 1a=block/state sobrevive, Stop 2a (stop_hook_active)
#      =libera+grava degraded-auto, em <5s
# C4 · anti-replay (LC-4): o verify_first_cmd injetado é extraído do texto e EXECUTADO de
#      verdade, provando que a prova de idempotência é executável como entregue
#
# Uso: bash evals/handoff-roundtrip-C1-C4.sh
# Exit: 0 = 3/3 rodadas com C1-C4 todos verdes · 1 = alguma rodada falhou

set -u
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
KIT_DIR="$(cd "$HERE/.." && pwd)"
IO="$KIT_DIR/hooks/_handoff_io.py"
INJECT="$KIT_DIR/hooks/handoff_inject.py"
GUARD="$KIT_DIR/hooks/handoff_guard.py"

PASS=0
FAIL=0
report() {
  if [ "$1" = "0" ]; then echo "  [OK] $2"; PASS=$((PASS + 1)); else echo "  [FAIL] $2"; FAIL=$((FAIL + 1)); fi
}

to_native() { if command -v cygpath >/dev/null 2>&1; then cygpath -m "$1"; else printf '%s' "$1"; fi }

run_round() {
  local round="$1"
  WORK="$(mktemp -d)"
  WORK_N="$(to_native "$WORK")"
  export CLAUDE_PROJECT_DIR="$WORK_N"

  # ---------- C1: round-trip básico ----------
  python "$IO" write --demo --lane solo >/dev/null
  OUT1=$(echo '{"hook_event_name":"SessionStart","session_id":"s1","lane_id":"solo"}' | python "$INJECT")
  LEDGER="$WORK/.claude/handoff/HANDOFF-LEDGER.jsonl"
  if echo "$OUT1" | grep -q "LC-4" && echo "$OUT1" | grep -q "additionalContext" && grep -q '"event": *"consumed"' "$LEDGER" 2>/dev/null; then
    report 0 "round$round C1: round-trip basico (bloco LC-4 + ledger consumed)"
  else
    report 1 "round$round C1 falhou: OUT1=$OUT1"
  fi
  rm -f "$WORK/.claude/handoff/HANDOFF-CURRENT-solo.json" "$LEDGER"

  # ---------- C2: staleness ----------
  python -c "
import json, sys
data = {
    'schema_version': '1.1', 'handoff_id': 'HO-STALE-solo', 'created_at': '2020-01-01T00:00:00-03:00',
    'trigger': 'manual', 'quality': 'full',
    'session': {'session_id': 's1', 'lane_id': 'solo'},
    'estado': {'resumo': 'teste stale', 'numeros': []},
    'git': {'head': '', 'branch': '', 'dirty': False, 'untracked': 0},
    'proximo_passo': [{'ordem': 1, 'descricao': 'nao deveria aparecer', 'verify_first_cmd': 'echo x'}],
    'valid_until': '2020-01-01T00:00:00-03:00',
}
print(json.dumps(data))
" | python "$IO" write --stdin >/dev/null
  OUT2=$(echo '{"hook_event_name":"SessionStart","session_id":"s1","lane_id":"solo"}' | python "$INJECT")
  if echo "$OUT2" | grep -q "STALE" && ! echo "$OUT2" | grep -q "PRÓXIMO PASSO"; then
    report 0 "round$round C2: staleness (STALE presente, PROXIMO PASSO ausente)"
  else
    report 1 "round$round C2 falhou: OUT2=$OUT2"
  fi
  rm -f "$WORK/.claude/handoff/HANDOFF-CURRENT-solo.json" "$LEDGER"

  # ---------- C3: degraded-auto ----------
  T0=$(date +%s)
  OUT3A=$(echo '{"hook_event_name":"Stop","session_id":"s1","lane_id":"solo","stop_hook_active":false}' | python "$GUARD")
  BLOCK_OK=0
  echo "$OUT3A" | grep -q '"decision": *"block"' && BLOCK_OK=1
  OUT3B=$(echo '{"hook_event_name":"Stop","session_id":"s1","lane_id":"solo","stop_hook_active":true}' | python "$GUARD")
  T1=$(date +%s)
  ELAPSED=$((T1 - T0))
  DEGRADED_OK=0
  if [ -f "$WORK/.claude/handoff/HANDOFF-CURRENT-solo.json" ] && grep -q '"quality": *"degraded-auto"' "$WORK/.claude/handoff/HANDOFF-CURRENT-solo.json"; then
    DEGRADED_OK=1
  fi
  if [ "$BLOCK_OK" = "1" ] && ! echo "$OUT3B" | grep -q '"decision"' && [ "$DEGRADED_OK" = "1" ] && [ "$ELAPSED" -lt 5 ]; then
    report 0 "round$round C3: Stop1=block, Stop2=libera+degraded-auto, em ${ELAPSED}s (<5s)"
  else
    report 1 "round$round C3 falhou: block_ok=$BLOCK_OK degraded_ok=$DEGRADED_OK elapsed=${ELAPSED}s OUT3B=$OUT3B"
  fi
  rm -f "$WORK/.claude/handoff/HANDOFF-CURRENT-solo.json" "$LEDGER"

  # ---------- C4: anti-replay (LC-4) — o verify_first_cmd É executado de verdade ----------
  NONCE="$WORK/nonce.txt"
  NONCE_N="$(to_native "$NONCE")"
  NONCE_PATH="$NONCE_N" python -c "
import json, os
nonce = os.environ['NONCE_PATH']
verify_cmd = 'python -c \"import sys,os; sys.exit(0 if os.path.exists(' + repr(nonce) + ') else 1)\"'
data = {
    'schema_version': '1.1', 'handoff_id': 'HO-LC4-solo', 'created_at': '2026-07-10T15:00:00-03:00',
    'trigger': 'manual', 'quality': 'full',
    'session': {'session_id': 's1', 'lane_id': 'solo'},
    'estado': {'resumo': 'teste LC-4', 'numeros': []},
    'git': {'head': '', 'branch': '', 'dirty': False, 'untracked': 0},
    'ja_executado': [{'acao': 'criou nonce', 'evidencia': 'nonce.txt', 'nunca_repetir': True}],
    'proximo_passo': [{'ordem': 1, 'descricao': 'nada', 'verify_first_cmd': verify_cmd}],
    'valid_until': '2099-01-01T00:00:00-03:00',
}
print(json.dumps(data))
" | python "$IO" write --stdin >/dev/null
  : > "$NONCE"  # nonce existe -> o verify_first_cmd deveria dar exit 0
  OUT4=$(echo '{"hook_event_name":"SessionStart","session_id":"s1","lane_id":"solo"}' | python "$INJECT")
  HAS_JA_EXECUTADO=0
  echo "$OUT4" | grep -q "JÁ EXECUTADO" && HAS_JA_EXECUTADO=1
  # Extrai o verify_first_cmd direto do JSON do handoff (UTF-8 explícito) em vez de recortar
  # o texto renderizado — evita o gotcha de encoding do stdin do Python via pipe no Windows/git-bash,
  # e prova a mesma coisa: render() só faz f-string do valor já presente no JSON.
  HANDOFF_JSON="$WORK_N/.claude/handoff/HANDOFF-CURRENT-solo.json"
  VERIFY_CMD=$(python -c "
import json
with open(r'$HANDOFF_JSON', encoding='utf-8') as f:
    data = json.load(f)
print(data['proximo_passo'][0]['verify_first_cmd'])
")
  # confirma tambem que o texto injetado contem o marcador (ASCII-safe, sem depender de acento)
  echo "$OUT4" | grep -q "ANTES DE EXECUTAR, RODE" || VERIFY_CMD=""
  RAN_OK=1
  if [ -n "$VERIFY_CMD" ]; then
    eval "$VERIFY_CMD" >/dev/null 2>&1 || RAN_OK=0
  else
    RAN_OK=0
  fi
  if [ "$HAS_JA_EXECUTADO" = "1" ] && [ "$RAN_OK" = "1" ]; then
    report 0 "round$round C4: bloco JA-EXECUTADO presente + verify_first_cmd extraido e executado (exit 0)"
  else
    report 1 "round$round C4 falhou: ja_executado=$HAS_JA_EXECUTADO verify_cmd=[$VERIFY_CMD] ran_ok=$RAN_OK OUT4=$OUT4"
  fi

  rm -rf "$WORK" 2>/dev/null
}

for round in 1 2 3; do
  echo "=== RODADA $round/3 ==="
  run_round "$round"
done

echo ""
TOTAL=$((PASS + FAIL))
echo "handoff-roundtrip-C1-C4: $PASS/$TOTAL checks verdes em 3 rodadas (pass^k=1.00 exige $TOTAL/$TOTAL)"
[ "$FAIL" = "0" ] && exit 0 || exit 1
