#!/usr/bin/env python3
"""
claude_md_from_profile (Operator Kit) - generates the CLAUDE.md block from operator-profile.yaml.

CLAUDE.md is born from the MODEL, not from memory: it reads `operator-profile.yaml` and writes
four sections that teach any agent to operate THIS project - and to stay silent where the
decision is not its to make. The floor comes FIRST, by crossing fields, never by opinion: each
line comes from a field in the profile; if the field is not there, the line does not exist.

    ## WHAT YOU DO NOT DECIDE     <- autonomy - guardrails - loop.forbidden_boundaries
    ## WHERE THINGS LIVE          <- paths.*
    ## THE RULES OF DONE          <- verification.done_criteria - ladder
    ## THE FLOW                   <- concurrency - loop - autonomy.default

The script governs ONLY the block between the markers:

    <!-- operator-kit:claude-md:begin -->
    ...
    <!-- operator-kit:claude-md:end -->

What is outside the markers belongs to the person and is never touched. Inside, the last line
is the SIGNATURE (hash of the profile + date). If the block was hand-edited - the signature does
not match the content - the script REFUSES to overwrite, shows what would change, and stops.

Usage:
    python claude_md_from_profile.py                       # finds the profile, writes ./CLAUDE.md
    python claude_md_from_profile.py --profile p.yaml --out CLAUDE.md
    python claude_md_from_profile.py --dry-run             # prints the block, does not write
    python claude_md_from_profile.py --force               # overwrites a hand-edited block
    python claude_md_from_profile.py --self-test

Exit: 0 written or no-op - 1 hand-edited block, refused (use --force) -
      2 invalid usage/profile - 3 write refused by the machine (see INSTRUCOES-DO-CLAUDE.md)

# Why: none of the kits generated CLAUDE.md from a structured model - the operator's profile
# was read by scripts and never written for the agent to read. Generation is CODE, not prose:
# "every cited field exists" has to be true by construction, not by discipline.

stdlib + PyYAML. v1.0.0 — 2026-09-20 (Operator Kit)
"""
from __future__ import annotations

import datetime as _dt
import hashlib
import io
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
try:
    from _lib.profile_loader import get as _loader_get  # type: ignore[import-not-found]
    from _lib.profile_loader import profile_path as find_profile
except Exception:  # noqa: BLE001 -- Why: without the loader, an explicit --profile keeps working; only automatic discovery falls back
    find_profile = None  # type: ignore[assignment]
    _loader_get = None  # type: ignore[assignment]

try:
    import yaml
except ImportError:
    yaml = None  # type: ignore[assignment]

BEGIN = "<!-- operator-kit:claude-md:begin -->"
END = "<!-- operator-kit:claude-md:end -->"

# Why: the profile keys and the example placeholder were translated, and this
# READER was left looking for the retired Portuguese sentinels — so `example` came back False
# for the shipped `profile.example.yaml`, the "generated from an EXAMPLE" warning was silently
# omitted, and the installer's smoke test failed on the flagship kit. Both spellings are read
# until 2.7.0: a profile written before the rename must keep getting its warning.
_EXAMPLE_FLAG_KEYS = ("_example", "_exemplo")
# Why `meu-projeto` is here: the cross-model checker found that `health-kit/profile.example.yaml`
# carried a THIRD placeholder, and its own header tells the reader to copy the file to
# `operator-profile.yaml`. Whoever obeyed got a block describing a project that does not exist,
# with the warning silently omitted — the exact symptom this list exists to prevent, through the
# one example file the first fix did not look at. The placeholder itself was unified, and the
# spelling stays readable here because a copy of it may already sit in someone's project.
_EXAMPLE_PROJECT_NAMES = ("your-project-name", "nome-do-projeto", "meu-projeto", "", None)
EXAMPLE_SENTINELS_LEGACY_REMOVED_IN = "2.7.0"
FALLBACK_NAME = "INSTRUCOES-DO-CLAUDE.md"  # literal: this is the name the person will look for

# Why: the signature is what separates "generated" (can overwrite) from "hand-edited" (cannot).
# It carries the hash of the generated CONTENT, so any edit inside the block invalidates it.
# Why: the signature points to the skill (which resolves the path via ${CLAUDE_PLUGIN_ROOT}), not
# to `python <script>`: the script lives in the plugin, not at the project root, and bare
# `python` does not exist on macOS.
_SIGNATURE_TEMPLATE = "*Bloco gerado do `{perfil}` em {data} - assinatura {hash} - para regerar: skill `claude-md-from-profile` (operator-kit; script {script}). Se editar este bloco a mao, a assinatura deixa de bater e eu paro de sobrescrever.*"


def _get(d: dict, dotted: str, default=None):
    """Dotted read THROUGH the kit loader, which carries the dual read of the profile keys
    renamed in 2.6.0 (legacy `projeto` -> `project`, and so on). Falls back to a plain walk only
    when the loader is not importable — the same degradation `find_profile` already has, and the
    only case in which a profile written before the rename would read as empty here."""
    if _loader_get is not None:
        return _loader_get(d, dotted, default)
    cur = d
    for k in dotted.split("."):
        if not isinstance(cur, dict) or k not in cur:
            return default
        cur = cur[k]
    return cur


def _list(x) -> list:
    return [str(i) for i in x] if isinstance(x, list) else []


# --------------------------------------------------------------------------
# the four sections - each line traces back to ONE field in the profile
# --------------------------------------------------------------------------
def section_do_not_decide(p: dict) -> list:
    """The floor. Never comes out empty: if nothing crossed, one honest line."""
    out = []
    by_action = _get(p, "autonomy.by_action", {}) or {}
    if isinstance(by_action, dict):
        for action, level in by_action.items():
            try:
                n = int(level)
            except (TypeError, ValueError):
                continue
            if n <= 1:
                out.append(f"- **{action}**: level {n} (`autonomy.by_action.{action}`). You PROPOSE, you do not execute. The person authorises.")
    for pth in _list(_get(p, "autonomy.sensitive_paths_auto_gate")):
        out.append(f"- Any write to `{pth}` falls into an automatic human gate (`autonomy.sensitive_paths_auto_gate`). Do not route around it.")
    for pth in _list(_get(p, "guardrails.protected_paths")):
        out.append(f"- `{pth}` is protected (`guardrails.protected_paths`): do not delete, do not move, do not mass-rewrite.")
    for br in _list(_get(p, "guardrails.protected_branches")):
        out.append(f"- Branch `{br}` is protected (`guardrails.protected_branches`): never push directly, never force.")
    for fam in _list(_get(p, "guardrails.block_families")):
        out.append(f"- The command family **{fam}** is BLOCKED (`guardrails.block_families`). Urgency is not an exception.")
    ext = _list(_get(p, "guardrails.external_send_tools"))
    if ext:
        out.append(f"- Sending outside ({', '.join(ext)}) is a human gate (`guardrails.external_send_tools`): prepare it, show it, do not fire it.")
    for fr in _list(_get(p, "loop.forbidden_boundaries")):
        out.append(f"- Forbidden loop boundary: `{fr}` (`loop.forbidden_boundaries`). If the task seems to require this, the task is wrong.")
    for sc in _list(_get(p, "loop.stop_conditions")):
        out.append(f"- STOP condition: **{sc}** (`loop.stop_conditions`). Stopping here is success, not failure.")
    if not out:
        out.append("- This profile has not recorded any limit yet. That means it is early, not that you are free. Ask before any irreversible action.")
    return out


def section_where_things_live(p: dict) -> list:
    paths = _get(p, "paths", {}) or {}
    if not isinstance(paths, dict) or not paths:
        return ["- `paths` is not filled in the profile. Do not assume any location - ask."]
    out = []
    for k, v in paths.items():
        if v is None or str(v).strip() == "":
            out.append(f"- **{k}**: *not configured* (`paths.{k}` empty). Do not invent a location.")
        else:
            out.append(f"- **{k}** lives at `{v}` (`paths.{k}`).")
    return out


def section_rules_of_done(p: dict) -> list:
    out = []
    crit = _get(p, "verification.done_criteria", {}) or {}
    if isinstance(crit, dict) and crit:
        out.append("\"Done\" only exists after the gate. By task type (`verification.done_criteria`):")
        for kind, cmds in crit.items():
            cmds_l = _list(cmds)
            if cmds_l:
                out.append(f"- **{kind}**: " + " | ".join(f"`{c}`" for c in cmds_l))
            else:
                out.append(f"- **{kind}**: *no criterion* - an empty list NEVER passes by omission (done_gate).")
    else:
        out.append("- `verification.done_criteria` is not filled. With no criterion, no task is \"done\" - the done_gate rejects an empty list by design.")
    ladder = _get(p, "verification.ladder", {}) or {}
    required = _list(_get(p, "verification.ladder_required"))
    minimum = _get(p, "verification.ladder_min_score")
    if isinstance(ladder, dict) and ladder:
        out.append(f"- Verification ladder (`verification.ladder`): {', '.join(str(k) for k in ladder.keys())}."
                   + (f" Mandatory: {', '.join(required)}." if required else "")
                   + (f" Minimum score: {minimum}." if minimum is not None else ""))
    out.append("- Three states, and only one is forbidden: **DONE** | **PARCIAL-DECLARADO** (say what is missing) | ~~silent partial~~. If you did not finish, declare it - silence is not a state.")
    return out


def section_flow(p: dict) -> list:
    out = []
    default = _get(p, "autonomy.default")
    intensity = _get(p, "intensity.default")
    if default is not None:
        out.append(f"- Default autonomy: **level {default}** (`autonomy.default`)" + (f", intensity **{intensity}** (`intensity.default`)." if intensity else "."))
    cap = _get(p, "concurrency.max_agents")
    wave = _get(p, "concurrency.wave_size")
    fb = _get(p, "concurrency.fallback")
    if cap is not None or wave is not None:
        out.append(f"- Parallelism: cap **{cap}** (`concurrency.max_agents`), waves of **{wave}** (`concurrency.wave_size`)" + (f", fallback `{fb}`." if fb else "."))
    charter = _get(p, "loop.charter")
    work = _get(p, "loop.work_list")
    if charter or work:
        out.append(f"- The loop reads the charter at `{charter}` and the queue at `{work}` (`loop.charter` / `loop.work_list`).")
    triggers = _list(_get(p, "loop.authorization_triggers"))
    if triggers:
        out.append(f"- BROAD execution only when the person says one of these: {', '.join(repr(g) for g in triggers)} (`loop.authorization_triggers`). Otherwise, one action at a time.")
    kw = _list(_get(p, "guardrails.approval_keywords"))
    if kw:
        out.append(f"- Words that count as human approval: {', '.join(repr(k) for k in kw)} (`guardrails.approval_keywords`). Nothing else counts.")
    if not out:
        out.append("- The profile configured neither autonomy nor concurrency. Operate at the lowest level until someone fills `autonomy.default`.")
    return out


def generate_block(profile: dict, profile_name: str, script_name: str, today: str | None = None) -> str:
    today = today or _dt.date.today().isoformat()
    example = any(profile.get(k) for k in _EXAMPLE_FLAG_KEYS) \
        or _get(profile, "project") in _EXAMPLE_PROJECT_NAMES
    lines = [BEGIN]
    if example:
        lines.append("> WARNING: THIS BLOCK WAS GENERATED FROM AN EXAMPLE PROFILE. The project below does not exist. Fill in `operator-profile.yaml` and regenerate.")
    lines += [
        f"# How to operate `{_get(profile, 'project', '?')}`",
        "",
        "This block was generated from `operator-profile.yaml`. It says what you may do, what",
        "you do not decide, and where things live. **Read the floor before the inventories.**",
        "",
        "## WHAT YOU DO NOT DECIDE", *section_do_not_decide(profile), "",
        "## WHERE THINGS LIVE", *section_where_things_live(profile), "",
        "## THE RULES OF DONE", *section_rules_of_done(profile), "",
        "## THE FLOW", *section_flow(profile), "",
    ]
    body = "\n".join(lines)
    h = hashlib.sha256(body.encode("utf-8")).hexdigest()[:12]
    lines.append(_SIGNATURE_TEMPLATE.format(perfil=profile_name, data=today, hash=h, script=script_name))
    lines.append(END)
    return "\n".join(lines) + "\n"


# --------------------------------------------------------------------------
# the block inside the file
# --------------------------------------------------------------------------
def _extract_block(text: str):
    i = text.find(BEGIN)
    j = text.find(END)
    if i < 0 or j < 0 or j < i:
        return None
    return text[i: j + len(END) + (1 if text[j + len(END): j + len(END) + 1] == "\n" else 0)]


def _block_was_edited(block: str) -> bool:
    """True if the signature does not match the content - someone edited inside the block."""
    lines = block.rstrip("\n").split("\n")
    if len(lines) < 3 or lines[-1] != END:
        return True
    assin = lines[-2]
    if "assinatura " not in assin:
        return True
    h_decl = assin.split("assinatura ")[1].split(" ")[0]
    body = "\n".join(lines[:-2])
    return hashlib.sha256(body.encode("utf-8")).hexdigest()[:12] != h_decl


def apply_block(target: Path, block: str, force: bool = False) -> tuple:
    """Returns (status, final_text). status: new | replaced | no-op | refused."""
    if not target.exists():
        # Why: once a CLAUDE.md exists, Claude Code reads it instead of AGENTS.md. A project that kept
        # its rules in AGENTS.md would lose them silently, so the new file imports it.
        if (target.parent / "AGENTS.md").exists():
            return "new", block + "\n@AGENTS.md\n"
        return "new", block
    raw = io.open(target, encoding="utf-8", newline="").read()
    # Why: a CLAUDE.md saved in CRLF would make the signature never match (the hash is of the LF
    # text) and the file would be "hand-edited" forever. Work is done in LF, returned in the original EOL.
    eol = "\r\n" if "\r\n" in raw else "\n"
    current = raw.replace("\r\n", "\n")
    old = _extract_block(current)
    if old is None:
        # the block goes at the TOP: the floor is the first thing the AI reads, before the person's text
        status, text = "new", block + "\n" + current
    elif _equal_ignoring_signature(old, block):
        return "no-op", raw
    elif _block_was_edited(old) and not force:
        return "refused", raw
    else:
        status, text = "replaced", current.replace(old, block, 1)
    return status, (text.replace("\n", eol) if eol != "\n" else text)


def agents_md_shadowed(target: Path) -> bool:
    """True when an AGENTS.md sits next to an existing CLAUDE.md that does not import it."""
    if not target.is_file() or not (target.parent / "AGENTS.md").exists():
        return False
    return "@AGENTS.md" not in io.open(target, encoding="utf-8").read()


def _equal_ignoring_signature(a: str, b: str) -> bool:
    """Compares the blocks IGNORING the signature line (which carries the date)."""
    def core(x):
        ls = x.rstrip("\n").split("\n")
        return "\n".join(l for l in ls if "assinatura " not in l)
    return core(a) == core(b)


def write_file(target: Path, text: str) -> Path:
    """Writes; if the machine refuses, falls back to the literal fallback name and returns IT."""
    try:
        with open(target, "w", encoding="utf-8", newline="") as fh:
            fh.write(text)
        return target
    except OSError:
        # Why: some machines silently refuse to write CLAUDE.md. Do not work around it via shell
        # or any other path - the refusal is the machine's protection. The fallback name is LITERAL:
        # it is what the person will look for.
        fb = target.parent / FALLBACK_NAME
        header = ("<!-- This file should be called CLAUDE.md. Writing under that name was\n"
               "     refused by this machine. RENAME IT TO CLAUDE.md and delete this block -->\n\n")
        with open(fb, "w", encoding="utf-8", newline="") as fh:
            fh.write(header + text)
        return fb


# --------------------------------------------------------------------------
def _self_test() -> None:
    import tempfile
    assert yaml is not None, "PyYAML is required for the self-test"
    example_path = Path(__file__).resolve().parents[1] / "profile.example.yaml"
    profile = yaml.safe_load(io.open(example_path, encoding="utf-8"))
    block = generate_block(profile, "profile.example.yaml", "x.py", today="2026-09-20")

    # form
    assert "{{" not in block, "placeholder not substituted"
    for sec in ("## WHAT YOU DO NOT DECIDE", "## WHERE THINGS LIVE", "## THE RULES OF DONE", "## THE FLOW"):
        assert sec in block, sec
    assert block.index("## WHAT YOU DO NOT DECIDE") < block.index("## WHERE THINGS LIVE"), "the floor comes FIRST"
    assert "EXAMPLE PROFILE" in block, "profile.example must be stamped as an example"
    assert block.startswith(BEGIN) and block.rstrip("\n").endswith(END)

    # every cited field exists: each cited `key.sub` is in the profile
    import re
    for ref in set(re.findall(r"\(`([a-z_]+(?:\.[a-z_]+)+)`", block)):
        assert _get(profile, ref, "__MISSING__") != "__MISSING__", f"cited a field that does not exist: {ref}"

    # floor never empty, even with an empty profile
    empty = generate_block({"project": "x"}, "p.yaml", "x.py", today="2026-09-20")
    assert "has not recorded any limit yet" in empty
    assert "is not filled" in empty

    with tempfile.TemporaryDirectory() as td:
        target = Path(td) / "CLAUDE.md"
        # 1st time: new
        st, txt = apply_block(target, block); assert st == "new"; write_file(target, txt)
        # 2nd time: no-op (idempotent)
        st, _ = apply_block(target, block); assert st == "no-op", st
        # file with the person's content OUTSIDE the block: preserved
        target.write_text("# My project\n\nmy notes\n", encoding="utf-8")
        st, txt = apply_block(target, block)
        assert st == "new" and txt.startswith(BEGIN) and txt.rstrip("\r\n").endswith("my notes"), "block on TOP, the person's text WHOLE below"
        write_file(target, txt)
        assert "my notes" in target.read_text(encoding="utf-8")
        # profile changes -> block replaced, and what's outside stays there
        block2 = generate_block({**profile, "project": "other"}, "p.yaml", "x.py", today="2026-09-20")
        st, txt = apply_block(target, block2); assert st == "replaced"; write_file(target, txt)
        t = target.read_text(encoding="utf-8")
        assert "my notes" in t and "other" in t and t.count(BEGIN) == 1
        # HAND edit inside the block -> refused; --force -> replaces
        t2 = t.replace("## THE FLOW", "## THE FLOW (I edited this)")
        target.write_text(t2, encoding="utf-8")
        st, _ = apply_block(target, block2); assert st == "refused", "a hand edit must be refused"
        st, txt = apply_block(target, block2, force=True); assert st == "replaced"
        # the instrument discriminates: an intact block is NOT "edited"
        assert not _block_was_edited(block2)
        assert _block_was_edited(block2.replace("## THE FLOW", "## THE FLOW x"))
        # write refusal -> literal fallback
        ro = Path(td) / "ro"; ro.mkdir()
        target_ro = ro / "CLAUDE.md"; target_ro.mkdir()   # a DIRECTORY with that name: open() fails
        dest = write_file(target_ro, block)
        assert dest.name == FALLBACK_NAME and dest.exists()
        assert "RENAME IT TO CLAUDE.md" in dest.read_text(encoding="utf-8")

    # a project that already keeps its instructions in AGENTS.md: once a CLAUDE.md exists, Claude Code
    # reads only the CLAUDE.md, so a new one must import AGENTS.md or the person's rules go silent
    with tempfile.TemporaryDirectory() as td:
        proj = Path(td)
        (proj / "AGENTS.md").write_text("# House rules\n", encoding="utf-8")
        st, txt = apply_block(proj / "CLAUDE.md", block)
        assert st == "new" and "\n@AGENTS.md\n" in txt, "a new CLAUDE.md must import the existing AGENTS.md"
        assert txt.startswith(BEGIN), "the floor still comes first"
        # an existing CLAUDE.md is the person's file: never rewritten, only reported
        (proj / "CLAUDE.md").write_text("# Mine\n", encoding="utf-8")
        assert agents_md_shadowed(proj / "CLAUDE.md"), "an existing CLAUDE.md without the import is reported"
        (proj / "CLAUDE.md").write_text("# Mine\n@AGENTS.md\n", encoding="utf-8")
        assert not agents_md_shadowed(proj / "CLAUDE.md")
    with tempfile.TemporaryDirectory() as td:
        # CONTROL: no AGENTS.md -> no import line and nothing to report
        st, txt = apply_block(Path(td) / "CLAUDE.md", block)
        assert "@AGENTS.md" not in txt and not agents_md_shadowed(Path(td) / "CLAUDE.md")
    print("self-test OK")


def main(argv) -> int:
    if argv and argv[0] in ("--self-test", "-t"):
        _self_test()
        return 0
    dry = "--dry-run" in argv
    force = "--force" in argv
    args = [a for a in argv if a not in ("--dry-run", "--force")]
    prof_path = None
    out_path = Path("CLAUDE.md")
    i = 0
    while i < len(args):
        if args[i] == "--profile" and i + 1 < len(args):
            prof_path = Path(args[i + 1]); i += 2; continue
        if args[i] == "--out" and i + 1 < len(args):
            out_path = Path(args[i + 1]); i += 2; continue
        print(__doc__.split("Usage:")[1].split("Exit:")[0], file=sys.stderr)
        return 2

    if yaml is None:
        print("claude_md_from_profile: PyYAML missing — install pyyaml", file=sys.stderr)
        return 2
    if prof_path is None:
        if find_profile is None:
            print("claude_md_from_profile: pass --profile <operator-profile.yaml>", file=sys.stderr)
            return 2
        prof_path = find_profile()
        if prof_path is None:
            print("claude_md_from_profile: no operator-profile.yaml found from the cwd. "
                  "CLAUDE.md is born from the profile, not the other way round — create the profile first "
                  "(cp profile.example.yaml operator-profile.yaml).", file=sys.stderr)
            return 2
    prof_path = Path(prof_path)
    try:
        profile = yaml.safe_load(io.open(prof_path, encoding="utf-8")) or {}
    except Exception as exc:  # noqa: BLE001 -- Why: broken YAML becomes exit 2 with the parser's message, never a half-generated block
        print(f"claude_md_from_profile: unreadable profile ({exc}). I do not fix it blind — correct the YAML.", file=sys.stderr)
        return 2
    if not isinstance(profile, dict):
        print("claude_md_from_profile: the profile is not a YAML mapping", file=sys.stderr)
        return 2

    block = generate_block(profile, prof_path.name, Path(__file__).name)
    if dry:
        sys.stdout.write(block)
        return 0

    status, text = apply_block(out_path, block, force=force)
    if status == "refused":
        print(f"claude_md_from_profile: the block in {out_path} was HAND-EDITED (the signature does not match). "
              "Not overwriting. See what would change with --dry-run; to overwrite anyway, --force.",
              file=sys.stderr)
        return 1
    if status == "no-op":
        print(f"claude_md_from_profile: {out_path} is already up to date with {prof_path.name} (no-op)")
        return 0
    dest = write_file(out_path, text)
    if dest.name == FALLBACK_NAME:
        print(f"claude_md_from_profile: this machine would not let me write {out_path.name}. The content is "
              f"complete in {dest} — rename it to {out_path.name} and you are done.", file=sys.stderr)
        return 3
    print(f"claude_md_from_profile: block {status} in {dest} (source: {prof_path.name})")
    if agents_md_shadowed(dest):
        print(f"claude_md_from_profile: WARNING — {dest.parent / 'AGENTS.md'} exists and {dest.name} does not "
              "import it. Claude Code reads only CLAUDE.md when both exist; add the line `@AGENTS.md` to "
              f"{dest.name} to keep those instructions.", file=sys.stderr)
    return 0


if __name__ == "__main__":
    try:
        sys.stdout.reconfigure(encoding="utf-8")  # type: ignore[attr-defined]
    except (AttributeError, ValueError):
        pass
    sys.exit(main(sys.argv[1:]))
