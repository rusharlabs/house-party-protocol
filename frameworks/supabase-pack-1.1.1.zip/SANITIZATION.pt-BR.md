[English](SANITIZATION.md) · [Português](SANITIZATION.pt-BR.md)

# SANITIZATION.pt-BR.md

Kit: supabase-pack 1.1.1

## Sanitização aplicada
- 9 padrão(ões) de exclusão de arquivo (ver manifesto interno da build — não distribuído)
- 0 substituição(ões) de texto aplicada(s)

## Resultado do lint
- status: ok
- counts: {'block': 0, 'warn': 0, 'total': 0}
