[English](SANITIZATION.md) · [Português](SANITIZATION.pt-BR.md)

# SANITIZATION.md

Kit: dev-squad-kit 1.2.3

## Sanitization applied
- 9 file exclusion pattern(s) (see the build's internal manifest — not distributed)
- 0 text replacement(s) applied

## Lint result
- status: ok
- counts: {'block': 0, 'warn': 0, 'total': 0}
