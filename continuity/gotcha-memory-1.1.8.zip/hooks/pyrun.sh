#!/usr/bin/env bash
# pyrun.sh - resolve the PROJECT's Python interpreter and run the hook with it.
#
# Why: hooks.json used to call a bare `python`. macOS and most Linux ship only `python3`;
# Windows ships only `python` (plus a `python3` that may be the Microsoft Store stub, which
# opens the Store and exits with an error). A hook that cannot find the interpreter fails in
# EVERY tool, silently - and the whole kit becomes decoration.
#
# Order: the project .venv (CLAUDE_PROJECT_DIR, else the cwd - Claude Code runs hooks at the
# project root) -> the right binary for this OS -> the other one. Never `py`.
#
# Two caveats:
#   . the project .venv runs with the trust you already give the project you opened - the
#     same thing any venv-aware tool does. To turn it off: HPP_PYRUN_NO_VENV=1.
#   . on Windows without Python, `command -v python` FINDS the WindowsApps alias (the Store
#     stub, which points at Microsoft.DesktopAppInstaller); it is skipped by the symlink
#     TARGET - Python installed from the Store/PythonManager also lives in WindowsApps and
#     is kept.
#
# --strict (first argument): for a slash command, not a hook. With no interpreter the shim then
# exits 127 instead of 0, because a ```! block that exits 0 renders as if it had worked and the
# model reads on; a hook keeps exit 0, since a hook without Python must never take the tool down.
strict=""
if [ "${1:-}" = "--strict" ]; then strict=1; shift; fi
# No bytecode: installed as a directory plugin, the kit runs from a clone of the product, and
# every hook (and what it imports) wrote __pycache__/*.pyc into it (B2-4).
export PYTHONDONTWRITEBYTECODE=1
root="${CLAUDE_PROJECT_DIR:-$PWD}"
if [ -z "${HPP_PYRUN_NO_VENV:-}" ]; then
  for c in "$root/.venv/bin/python" "$root/.venv/Scripts/python.exe"; do
    [ -x "$c" ] && exec "$c" "$@"
  done
fi
case "$(uname -s 2>/dev/null)" in
  MINGW*|MSYS*|CYGWIN*) order="python python3" ;;
  *)                    order="python3 python" ;;
esac
for c in $order; do
  bin="$(command -v "$c" 2>/dev/null || true)"
  [ -n "$bin" ] || continue
  # the WindowsApps alias is a symlink: the real Python points at PythonSoftwareFoundation.*;
  # the Store stub points at Microsoft.DesktopAppInstaller_*. The target decides.
  case "$(readlink -f "$bin" 2>/dev/null || echo "$bin")" in *DesktopAppInstaller*) continue ;; esac
  exec "$bin" "$@"
done
if [ -n "$strict" ]; then
  echo "pyrun.sh: no Python interpreter found (python3/python) - the command did not run" >&2
  exit 127
fi
echo "pyrun.sh: no Python interpreter found (python3/python) - hook did not run" >&2
exit 0   # WARN-only: a hook without Python must never take the tool down
