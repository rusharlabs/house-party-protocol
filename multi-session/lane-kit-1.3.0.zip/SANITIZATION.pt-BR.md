[English](SANITIZATION.md) · [Português](SANITIZATION.pt-BR.md)

# SANITIZATION.pt-BR.md

Kit: lane-kit 1.3.0

## Sanitização aplicada
- 7 padrão(ões) de exclusão de arquivo (ver manifesto interno da build — não distribuído)
- 0 substituição(ões) de texto aplicada(s)

## Resultado do lint
- status: ok
- counts: {'block': 0, 'warn': 0, 'total': 0}
