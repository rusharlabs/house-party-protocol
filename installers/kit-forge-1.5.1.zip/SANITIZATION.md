[English](SANITIZATION.md) · [Português](SANITIZATION.pt-BR.md)

# SANITIZATION.md

Kit: kit-forge 1.5.1

## Sanitization applied
- 17 file exclusion pattern(s) (see the build's internal manifest — not distributed)
- 0 text replacement(s) applied

## Lint result
- status: ok
- counts: {'block': 0, 'warn': 0, 'total': 0}
