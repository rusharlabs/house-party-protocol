---
name: pre-clear-boot-block
description: Before a /clear, emits the DONE / MISSING / read-in-this-order block so the fresh session resumes with zero loss
---

> **Auto-Trigger:** When the context is growing, a wave/feature closes, or the operator signals an intent to /clear or the end of a long session
> **Keywords:** "/clear", "about to clear", "pre-clear", "boot", "handoff", "resume", "next session", "close session"
> **Priority:** MEDIUM
> **Tools:** Bash, Read, Write
> **Related doctrine:** `rules/stale-replay-guard.md` (LC-4: the boot bundle is a reference, not a queue), `rules/learned-corrections.md` (LC-1: re-verify live in STEP 0).

# pre-clear-boot-block — a 1-block handoff before the /clear

Before a `/clear`, the fresh session needs to resume without losing the thread. This command produces a self-contained block. **It reuses `autoprompt_resume` — it does not re-extract state.**

## Contract

**INPUT:** none (reads the SSoT declared in `paths.boot_doc`/`paths.state_ssot` of `operator-profile.yaml` + local `git log`).

**OUTPUT:** Markdown block printed to stdout with 3 sections (DONE / MISSING / BOOT), ready to paste into the next session; optionally 1 commit (0 push).

**EXIT CODES:**

| Exit | Meaning |
|---|---|
| 0 | block generated and printed |
| 2 | script not found / hook path not resolved (broken installation) |

**STATE IT TOUCHES:**

| File/resource | Reads/Writes | Purpose |
|---|---|---|
| `paths.state_ssot` (e.g. `docs/plans/execucao/00-STATE.md`) | Reads | open items |
| `paths.boot_doc` | Reads | suggested reading order |
| `git log` | Reads | latest commits (context for "what is already DONE") |
| `.git` (optional commit) | Writes | if `commita: true` in the profile — commit per path, 0 push |

## Process
1. **Fire/read the RESUME-NEXT:** `python ${CLAUDE_PLUGIN_ROOT}/hooks/autoprompt_resume.py --print` (it already aggregates the open items from the SSoT + the latest commits, honestly). Do not reimplement extraction.
2. **Add the reading order** (boot docs from `paths.boot_doc` + related) — "read these files IN THIS order".
3. **Assemble the block** with 3 sections:
   - **DONE** — what is durably done (committed).
   - **MISSING** — what remains, by owner (autonomous / human gate / delegable).
   - **BOOT** — reading order + the pasteable self-prompt.
4. **Optionally commit** the state (`commita` y/n configurable) — commit per path, 0 push.
5. **Print the block** ready to paste into the next session.

## When NOT to Activate
- Short session with no accumulated state.
- When `save`/`autoprompt_resume` already cover it (do not duplicate the handoff).
- The neighbouring skill `dual-report-builder` covers dual-audience reports — that is not this (this is a session handoff, not a business report).

## Executed examples

```console
$ python hooks/autoprompt_resume.py --print
# RESUME-NEXT — retomada automática (autoprompt cross-sessão)

> Gerado pelo Stop hook `autoprompt_resume.py` (Operator Kit) em 2026-07-10 14:51 BRT.
> **Boot-doc canônico:** `docs\plans\...` · **SSoT:** `docs\plans\execucao\00-STATE.md`.

## PASSO 0 (re-verificar AO VIVO — LC-1)
    git log --oneline -3
    # revise as pendências abertas em docs\plans\execucao\00-STATE.md

[... bloco completo continua com DONE/FALTA/BOOT — truncado aqui por brevidade ...]
```
<!-- executed: 2026-07-10 · exit=0 -->

```console
$ python hooks/autoprompt_resume.py --self-test
self-test OK
```
<!-- executed: 2026-07-10 · exit=0 -->

```console
$ python operator-kit/hooks/autoprompt_resume.py --print
python.exe: can't open file '...\operator-kit\hooks\autoprompt_resume.py': [Errno 2] No such file or directory
```
<!-- executed: 2026-07-10 · exit=2 -->
(real reproduction of the bug this skill had before the fix: a raw relative path without `${CLAUDE_PLUGIN_ROOT}` breaks outside the kit directory — which is why step 1 now uses the anchor.)

## Proof

```bash
python ${CLAUDE_PLUGIN_ROOT}/hooks/autoprompt_resume.py --self-test
```

## See also
`autoprompt_resume.py` (input), `loop-charter-template` (the canonical BOOT-PROMPT), `gate-sheet-collector` (the MISSING → human-gate part).
